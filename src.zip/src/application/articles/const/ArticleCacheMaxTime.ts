/**
 * Время хранения в кэше для статей
 */
export const ARTICLE_CACHE_TTL = 600000;
