/**
 * Максимальная длина заголовка статьи
 */
export const MAX_ARTICLE_NAME_LENGTH = 200;
