/** Минимальная длина пароля */
export const MIN_PASSWORD_LENGTH = 4;
