/**Текущий авторизованный пользователь */
export interface IAuthUser {
  login: string;
  id: string;
  name: string;
}
